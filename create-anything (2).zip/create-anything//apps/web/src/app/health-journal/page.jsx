"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import useUpload from "@/utils/useUpload";
import {
  PawPrint,
  Plus,
  ArrowLeft,
  Heart,
  Camera,
  Calendar,
  X,
  Edit,
  Trash2,
  Upload,
  FileText,
  Activity,
} from "lucide-react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [healthLogs, setHealthLogs] = useState([]);
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedPet, setSelectedPet] = useState("");
  const [formData, setFormData] = useState({
    pet_id: "",
    log_type: "symptom",
    title: "",
    description: "",
    date_logged: new Date().toISOString().split("T")[0],
    photo_url: "",
  });

  const { upload, uploading, error: uploadError } = useUpload();

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      setLoading(true);

      // Load pets
      const petsResponse = await fetch("/api/pets");
      if (petsResponse.ok) {
        const petsData = await petsResponse.json();
        setPets(petsData.pets || []);
      }

      // Load health logs
      const logsResponse = await fetch("/api/health-logs");
      if (logsResponse.ok) {
        const logsData = await logsResponse.json();
        setHealthLogs(logsData.logs || []);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.pet_id || !formData.title) {
      alert("Please fill in all required fields");
      return;
    }

    try {
      const response = await fetch("/api/health-logs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        await loadData();
        setShowAddForm(false);
        setFormData({
          pet_id: "",
          log_type: "symptom",
          title: "",
          description: "",
          date_logged: new Date().toISOString().split("T")[0],
          photo_url: "",
        });
      } else {
        const error = await response.json();
        alert(error.error || "Failed to create health log");
      }
    } catch (error) {
      console.error("Error creating health log:", error);
      alert("Failed to create health log");
    }
  };

  const deleteLog = async (logId) => {
    if (!confirm("Are you sure you want to delete this health log?")) return;

    try {
      const response = await fetch(`/api/health-logs?id=${logId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await loadData();
      }
    } catch (error) {
      console.error("Error deleting health log:", error);
    }
  };

  const handlePhotoUpload = async (event) => {
    const file = event.target.files[0];
    if (file) {
      try {
        const uploadedFile = await upload(file);
        setFormData((prev) => ({ ...prev, photo_url: uploadedFile.cdnUrl }));
      } catch (error) {
        console.error("Upload failed:", error);
        alert("Failed to upload photo");
      }
    }
  };

  const getLogIcon = (type) => {
    switch (type) {
      case "symptom":
        return "🩺";
      case "medication":
        return "💊";
      case "vet_visit":
        return "🏥";
      case "vaccination":
        return "💉";
      case "weight":
        return "⚖️";
      case "behavior":
        return "🐾";
      case "diet":
        return "🍖";
      default:
        return "📝";
    }
  };

  const getLogColor = (type) => {
    switch (type) {
      case "symptom":
        return "text-red-600 bg-red-50 border-red-200";
      case "medication":
        return "text-blue-600 bg-blue-50 border-blue-200";
      case "vet_visit":
        return "text-green-600 bg-green-50 border-green-200";
      case "vaccination":
        return "text-purple-600 bg-purple-50 border-purple-200";
      case "weight":
        return "text-orange-600 bg-orange-50 border-orange-200";
      case "behavior":
        return "text-pink-600 bg-pink-50 border-pink-200";
      case "diet":
        return "text-yellow-600 bg-yellow-50 border-yellow-200";
      default:
        return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "";
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-green-500 border-t-transparent mx-auto mb-4"></div>
          <p className="text-green-700 font-medium">
            Loading health journal...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    if (typeof window !== "undefined") {
      window.location.href = "/account/signin";
    }
    return null;
  }

  const filteredLogs = selectedPet
    ? healthLogs.filter((log) => log.pet_id.toString() === selectedPet)
    : healthLogs;

  const logsByPet = pets.map((pet) => ({
    ...pet,
    logCount: healthLogs.filter((log) => log.pet_id === pet.id).length,
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm border-b border-green-100 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => (window.location.href = "/dashboard")}
                className="text-gray-600 hover:text-gray-800 p-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                <div className="bg-pink-100 p-2 rounded-full">
                  <Heart className="w-6 h-6 text-pink-600" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-800">
                    Health Journal
                  </h1>
                  <p className="text-sm text-gray-600">
                    Track your pets' health records
                  </p>
                </div>
              </div>
            </div>
            <button
              onClick={() => setShowAddForm(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              New Entry
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Pet Filter & Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl border border-green-100 shadow-sm p-6">
              <h3 className="font-semibold text-gray-800 mb-4">
                Filter by Pet
              </h3>
              <select
                value={selectedPet}
                onChange={(e) => setSelectedPet(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500 mb-4"
              >
                <option value="">All Pets</option>
                {pets.map((pet) => (
                  <option key={pet.id} value={pet.id.toString()}>
                    {pet.name}
                  </option>
                ))}
              </select>

              <div className="space-y-2">
                {logsByPet.map((pet) => (
                  <div
                    key={pet.id}
                    className="flex items-center justify-between text-sm"
                  >
                    <span className="text-gray-600">{pet.name}</span>
                    <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">
                      {pet.logCount} logs
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white rounded-xl p-4 border border-green-100 shadow-sm text-center">
                <div className="text-2xl font-bold text-gray-800">
                  {healthLogs.length}
                </div>
                <div className="text-sm text-gray-600">Total Logs</div>
              </div>
              <div className="bg-white rounded-xl p-4 border border-green-100 shadow-sm text-center">
                <div className="text-2xl font-bold text-gray-800">
                  {
                    healthLogs.filter((log) => log.log_type === "vet_visit")
                      .length
                  }
                </div>
                <div className="text-sm text-gray-600">Vet Visits</div>
              </div>
              <div className="bg-white rounded-xl p-4 border border-green-100 shadow-sm text-center">
                <div className="text-2xl font-bold text-gray-800">
                  {
                    healthLogs.filter((log) => log.log_type === "medication")
                      .length
                  }
                </div>
                <div className="text-sm text-gray-600">Medications</div>
              </div>
              <div className="bg-white rounded-xl p-4 border border-green-100 shadow-sm text-center">
                <div className="text-2xl font-bold text-gray-800">
                  {
                    healthLogs.filter((log) => log.log_type === "symptom")
                      .length
                  }
                </div>
                <div className="text-sm text-gray-600">Symptoms</div>
              </div>
            </div>

            {/* Health Logs */}
            <div className="bg-white rounded-xl border border-green-100 shadow-sm">
              <div className="p-6 border-b border-gray-100">
                <h2 className="text-xl font-semibold text-gray-800">
                  Health Records{" "}
                  {selectedPet &&
                    `for ${pets.find((p) => p.id.toString() === selectedPet)?.name}`}
                </h2>
              </div>
              <div className="p-6">
                {filteredLogs.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="bg-pink-100 p-4 rounded-full w-fit mx-auto mb-4">
                      <Heart className="w-12 h-12 text-pink-600" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-800 mb-2">
                      No health logs yet
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Start tracking your pet's health by adding your first
                      entry
                    </p>
                    <button
                      onClick={() => setShowAddForm(true)}
                      className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
                    >
                      Add First Entry
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredLogs
                      .sort(
                        (a, b) =>
                          new Date(b.date_logged) - new Date(a.date_logged),
                      )
                      .map((log) => (
                        <div
                          key={log.id}
                          className="border border-gray-200 rounded-lg p-6 hover:border-green-200 transition-colors"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex gap-4 flex-1">
                              <div className="text-2xl">
                                {getLogIcon(log.log_type)}
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center gap-3 mb-2">
                                  <h3 className="font-semibold text-gray-800">
                                    {log.title}
                                  </h3>
                                  <span
                                    className={`px-2 py-1 text-xs rounded-full border ${getLogColor(log.log_type)}`}
                                  >
                                    {log.log_type.replace("_", " ")}
                                  </span>
                                </div>
                                <p className="text-sm text-gray-600 mb-2">
                                  {log.pet_name} • {formatDate(log.date_logged)}
                                </p>
                                {log.description && (
                                  <p className="text-gray-700 mb-3">
                                    {log.description}
                                  </p>
                                )}
                                {log.photo_url && (
                                  <div className="mb-3">
                                    <img
                                      src={log.photo_url}
                                      alt="Health log photo"
                                      className="max-w-sm rounded-lg border border-gray-200"
                                    />
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                                title="Edit"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => deleteLog(log.id)}
                                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                title="Delete"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Health Log Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-800">
                  New Health Entry
                </h2>
                <button
                  onClick={() => setShowAddForm(false)}
                  className="text-gray-500 hover:text-gray-700 p-1"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Pet *
                </label>
                <select
                  value={formData.pet_id}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, pet_id: e.target.value }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  required
                >
                  <option value="">Select a pet</option>
                  {pets.map((pet) => (
                    <option key={pet.id} value={pet.id}>
                      {pet.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Log Type
                </label>
                <select
                  value={formData.log_type}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      log_type: e.target.value,
                    }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                >
                  <option value="symptom">Symptom</option>
                  <option value="medication">Medication</option>
                  <option value="vet_visit">Vet Visit</option>
                  <option value="vaccination">Vaccination</option>
                  <option value="weight">Weight Check</option>
                  <option value="behavior">Behavior</option>
                  <option value="diet">Diet Change</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, title: e.target.value }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  placeholder="e.g., Annual checkup, Limping on left paw"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  value={formData.date_logged}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      date_logged: e.target.value,
                    }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  rows="4"
                  placeholder="Describe symptoms, treatments, observations, etc..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Photo
                </label>
                <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 text-center">
                  {formData.photo_url ? (
                    <div className="space-y-2">
                      <img
                        src={formData.photo_url}
                        alt="Preview"
                        className="max-w-32 mx-auto rounded-lg"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setFormData((prev) => ({ ...prev, photo_url: "" }))
                        }
                        className="text-sm text-red-600 hover:text-red-700"
                      >
                        Remove photo
                      </button>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <label className="cursor-pointer">
                        <span className="text-green-600 hover:text-green-700 font-medium">
                          {uploading ? "Uploading..." : "Choose photo"}
                        </span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoUpload}
                          disabled={uploading}
                          className="hidden"
                        />
                      </label>
                      <p className="text-xs text-gray-500 mt-1">
                        JPG, PNG up to 10MB
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;
