"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  PawPrint,
  Plus,
  ArrowLeft,
  Calendar,
  Clock,
  Bell,
  Check,
  X,
  Edit,
  Trash2,
  AlertCircle,
  CheckCircle,
} from "lucide-react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [schedules, setSchedules] = useState([]);
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    pet_id: "",
    title: "",
    description: "",
    schedule_type: "feeding",
    frequency: "daily",
    time_of_day: "",
    days_of_week: [],
  });

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      setLoading(true);

      // Load pets
      const petsResponse = await fetch("/api/pets");
      if (petsResponse.ok) {
        const petsData = await petsResponse.json();
        setPets(petsData.pets || []);
      }

      // Load schedules
      const schedulesResponse = await fetch("/api/care-schedules");
      if (schedulesResponse.ok) {
        const schedulesData = await schedulesResponse.json();
        setSchedules(schedulesData.schedules || []);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.pet_id || !formData.title) {
      alert("Please fill in all required fields");
      return;
    }

    try {
      const response = await fetch("/api/care-schedules", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        await loadData();
        setShowAddForm(false);
        setFormData({
          pet_id: "",
          title: "",
          description: "",
          schedule_type: "feeding",
          frequency: "daily",
          time_of_day: "",
          days_of_week: [],
        });
      } else {
        const error = await response.json();
        alert(error.error || "Failed to create schedule");
      }
    } catch (error) {
      console.error("Error creating schedule:", error);
      alert("Failed to create schedule");
    }
  };

  const markComplete = async (scheduleId) => {
    try {
      const response = await fetch("/api/care-schedules", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          schedule_id: scheduleId,
          action: "complete",
        }),
      });

      if (response.ok) {
        await loadData();
      }
    } catch (error) {
      console.error("Error marking complete:", error);
    }
  };

  const deleteSchedule = async (scheduleId) => {
    if (!confirm("Are you sure you want to delete this schedule?")) return;

    try {
      const response = await fetch(`/api/care-schedules?id=${scheduleId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await loadData();
      }
    } catch (error) {
      console.error("Error deleting schedule:", error);
    }
  };

  const getScheduleIcon = (type) => {
    switch (type) {
      case "feeding":
        return "🍽️";
      case "walk":
        return "🚶";
      case "medication":
        return "💊";
      case "vet_appointment":
        return "🏥";
      case "grooming":
        return "🛁";
      case "exercise":
        return "⚽";
      default:
        return "📅";
    }
  };

  const formatTime = (timeString) => {
    if (!timeString) return "";
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatNextDue = (dateString) => {
    if (!dateString) return "Not scheduled";
    const date = new Date(dateString);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    const isTomorrow =
      date.toDateString() === new Date(now.getTime() + 86400000).toDateString();

    if (isToday) return "Today";
    if (isTomorrow) return "Tomorrow";

    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: date.getFullYear() !== now.getFullYear() ? "numeric" : undefined,
    });
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-green-500 border-t-transparent mx-auto mb-4"></div>
          <p className="text-green-700 font-medium">Loading schedules...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    if (typeof window !== "undefined") {
      window.location.href = "/account/signin";
    }
    return null;
  }

  const upcomingSchedules = schedules.filter(
    (s) =>
      s.next_due &&
      new Date(s.next_due) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
  );

  const overdueSchedules = schedules.filter(
    (s) => s.next_due && new Date(s.next_due) < new Date(),
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm border-b border-green-100 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => (window.location.href = "/dashboard")}
                className="text-gray-600 hover:text-gray-800 p-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                <div className="bg-purple-100 p-2 rounded-full">
                  <Calendar className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-800">
                    Care Schedule
                  </h1>
                  <p className="text-sm text-gray-600">
                    Manage your pets' routines
                  </p>
                </div>
              </div>
            </div>
            <button
              onClick={() => setShowAddForm(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              New Schedule
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 border border-green-100 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="bg-red-100 p-3 rounded-lg">
                <AlertCircle className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">
                  {overdueSchedules.length}
                </p>
                <p className="text-sm text-gray-600">Overdue</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-green-100 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="bg-orange-100 p-3 rounded-lg">
                <Clock className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">
                  {upcomingSchedules.length}
                </p>
                <p className="text-sm text-gray-600">This Week</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-green-100 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">
                  {schedules.filter((s) => s.is_active).length}
                </p>
                <p className="text-sm text-gray-600">Active Schedules</p>
              </div>
            </div>
          </div>
        </div>

        {/* Overdue Section */}
        {overdueSchedules.length > 0 && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-6 mb-8">
            <div className="flex items-center gap-2 mb-4">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <h2 className="text-lg font-semibold text-red-800">
                Overdue Tasks
              </h2>
            </div>
            <div className="space-y-3">
              {overdueSchedules.map((schedule) => (
                <div
                  key={schedule.id}
                  className="flex items-center justify-between bg-white p-4 rounded-lg border border-red-100"
                >
                  <div className="flex items-center gap-4">
                    <div className="text-2xl">
                      {getScheduleIcon(schedule.schedule_type)}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800">
                        {schedule.title}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {schedule.pet_name} • Due:{" "}
                        {formatNextDue(schedule.next_due)}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => markComplete(schedule.id)}
                    className="bg-green-600 hover:bg-green-700 text-white p-2 rounded-lg transition-colors"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* All Schedules */}
        <div className="bg-white rounded-xl border border-green-100 shadow-sm">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-semibold text-gray-800">
              All Schedules
            </h2>
          </div>
          <div className="p-6">
            {schedules.length === 0 ? (
              <div className="text-center py-12">
                <div className="bg-purple-100 p-4 rounded-full w-fit mx-auto mb-4">
                  <Calendar className="w-12 h-12 text-purple-600" />
                </div>
                <h3 className="text-lg font-medium text-gray-800 mb-2">
                  No schedules yet
                </h3>
                <p className="text-gray-600 mb-4">
                  Create your first care schedule to stay on top of your pet's
                  needs
                </p>
                <button
                  onClick={() => setShowAddForm(true)}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
                >
                  Create Schedule
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {schedules.map((schedule) => (
                  <div
                    key={schedule.id}
                    className="border border-gray-200 rounded-lg p-4 hover:border-green-200 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="text-2xl">
                          {getScheduleIcon(schedule.schedule_type)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-gray-800">
                              {schedule.title}
                            </h3>
                            {!schedule.is_active && (
                              <span className="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded-full">
                                Inactive
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mb-2">
                            {schedule.pet_name} • {schedule.frequency}
                            {schedule.time_of_day &&
                              ` at ${formatTime(schedule.time_of_day)}`}
                          </p>
                          {schedule.description && (
                            <p className="text-sm text-gray-500">
                              {schedule.description}
                            </p>
                          )}
                          <div className="flex items-center gap-4 mt-2">
                            <span className="text-sm text-gray-600">
                              Next: {formatNextDue(schedule.next_due)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => markComplete(schedule.id)}
                          className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title="Mark as complete"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                          title="Edit"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteSchedule(schedule.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Schedule Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-800">
                  New Care Schedule
                </h2>
                <button
                  onClick={() => setShowAddForm(false)}
                  className="text-gray-500 hover:text-gray-700 p-1"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Pet *
                </label>
                <select
                  value={formData.pet_id}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, pet_id: e.target.value }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  required
                >
                  <option value="">Select a pet</option>
                  {pets.map((pet) => (
                    <option key={pet.id} value={pet.id}>
                      {pet.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, title: e.target.value }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  placeholder="e.g., Morning feeding"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Type
                </label>
                <select
                  value={formData.schedule_type}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      schedule_type: e.target.value,
                    }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                >
                  <option value="feeding">Feeding</option>
                  <option value="walk">Walk</option>
                  <option value="medication">Medication</option>
                  <option value="vet_appointment">Vet Appointment</option>
                  <option value="grooming">Grooming</option>
                  <option value="exercise">Exercise</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Frequency
                </label>
                <select
                  value={formData.frequency}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      frequency: e.target.value,
                    }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="custom">Custom</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Time
                </label>
                <input
                  type="time"
                  value={formData.time_of_day}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      time_of_day: e.target.value,
                    }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  rows="3"
                  placeholder="Additional notes..."
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                >
                  Create Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;
