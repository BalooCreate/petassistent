import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Get all care schedules for the current user
export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const url = new URL(request.url);
    const petId = url.searchParams.get("pet_id");

    let query = `
      SELECT cs.*, p.name as pet_name
      FROM care_schedules cs
      JOIN pets p ON cs.pet_id = p.id
      WHERE cs.user_id = $1
    `;
    const params = [userId];

    if (petId) {
      query += ` AND cs.pet_id = $2`;
      params.push(petId);
    }

    query += ` ORDER BY cs.next_due ASC NULLS LAST, cs.created_at DESC`;

    const schedules = await sql(query, params);

    return Response.json({ schedules });
  } catch (error) {
    console.error("GET /api/care-schedules error:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

// Create a new care schedule
export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const {
      pet_id,
      title,
      description,
      schedule_type,
      frequency,
      time_of_day,
      days_of_week,
      next_due,
    } = body;

    if (!pet_id || !title || !schedule_type || !frequency) {
      return Response.json(
        {
          error: "Pet ID, title, schedule type, and frequency are required",
        },
        { status: 400 },
      );
    }

    // Verify pet belongs to user
    const petCheck = await sql`
      SELECT id FROM pets WHERE id = ${pet_id} AND user_id = ${userId}
    `;

    if (petCheck.length === 0) {
      return Response.json({ error: "Pet not found" }, { status: 404 });
    }

    // Calculate next due date if not provided
    let calculatedNextDue = next_due;
    if (!calculatedNextDue) {
      const now = new Date();

      if (frequency === "daily") {
        calculatedNextDue = new Date(now.getTime() + 24 * 60 * 60 * 1000);
      } else if (frequency === "weekly") {
        calculatedNextDue = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      } else if (frequency === "monthly") {
        calculatedNextDue = new Date(now);
        calculatedNextDue.setMonth(calculatedNextDue.getMonth() + 1);
      }

      // Set time if provided
      if (calculatedNextDue && time_of_day) {
        const [hours, minutes] = time_of_day.split(":");
        calculatedNextDue.setHours(parseInt(hours), parseInt(minutes), 0, 0);
      }
    }

    const result = await sql`
      INSERT INTO care_schedules (
        pet_id, user_id, title, description, schedule_type, frequency, 
        time_of_day, days_of_week, next_due
      )
      VALUES (
        ${pet_id}, ${userId}, ${title.trim()}, ${description || null}, 
        ${schedule_type}, ${frequency}, ${time_of_day || null}, 
        ${days_of_week || null}, ${calculatedNextDue}
      )
      RETURNING *
    `;

    const schedule = result[0];
    return Response.json({ schedule }, { status: 201 });
  } catch (error) {
    console.error("POST /api/care-schedules error:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

// Update care schedule (for completing tasks, editing, etc.)
export async function PATCH(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const { schedule_id, action, ...updateData } = body;

    if (!schedule_id) {
      return Response.json(
        { error: "Schedule ID is required" },
        { status: 400 },
      );
    }

    // Verify the schedule belongs to the user
    const scheduleCheck = await sql`
      SELECT cs.*, p.name as pet_name
      FROM care_schedules cs
      JOIN pets p ON cs.pet_id = p.id
      WHERE cs.id = ${schedule_id} AND cs.user_id = ${userId}
    `;

    if (scheduleCheck.length === 0) {
      return Response.json(
        { error: "Schedule not found or unauthorized" },
        { status: 404 },
      );
    }

    const schedule = scheduleCheck[0];

    if (action === "complete") {
      // Mark as complete and calculate next due date
      let nextDue = null;
      const now = new Date();

      if (schedule.frequency === "daily") {
        nextDue = new Date(now.getTime() + 24 * 60 * 60 * 1000);
      } else if (schedule.frequency === "weekly") {
        nextDue = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      } else if (schedule.frequency === "monthly") {
        nextDue = new Date(now);
        nextDue.setMonth(nextDue.getMonth() + 1);
      }

      if (nextDue && schedule.time_of_day) {
        const [hours, minutes] = schedule.time_of_day.split(":");
        nextDue.setHours(parseInt(hours), parseInt(minutes), 0, 0);
      }

      // Update the schedule with new next_due date
      await sql`
        UPDATE care_schedules 
        SET next_due = ${nextDue}, updated_at = NOW()
        WHERE id = ${schedule_id}
      `;

      // Log the completion
      await sql`
        INSERT INTO care_completions (care_schedule_id, user_id, completed_at)
        VALUES (${schedule_id}, ${userId}, NOW())
      `;

      return Response.json({
        message: "Task marked as complete",
        next_due: nextDue,
      });
    } else {
      // General update - not implemented in this version
      return Response.json(
        { error: "Update action not implemented" },
        { status: 400 },
      );
    }
  } catch (error) {
    console.error("PATCH /api/care-schedules error:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

// Delete a care schedule
export async function DELETE(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const url = new URL(request.url);
    const scheduleId = url.searchParams.get("id");

    if (!scheduleId) {
      return Response.json(
        { error: "Schedule ID is required" },
        { status: 400 },
      );
    }

    // Verify the schedule belongs to the user
    const scheduleCheck = await sql`
      SELECT id FROM care_schedules WHERE id = ${scheduleId} AND user_id = ${userId}
    `;

    if (scheduleCheck.length === 0) {
      return Response.json(
        { error: "Schedule not found or unauthorized" },
        { status: 404 },
      );
    }

    await sql`DELETE FROM care_schedules WHERE id = ${scheduleId}`;

    return Response.json({ message: "Schedule deleted successfully" });
  } catch (error) {
    console.error("DELETE /api/care-schedules error:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
