import {
  Heart,
  PawPrint,
  Calendar,
  MessageCircle,
  Camera,
  Shield,
  Users,
  Star,
  ArrowRight,
  Check,
  Activity,
  Bell,
} from "lucide-react";
import useUser from "@/utils/useUser";

function MainComponent() {
  const { data: user, loading } = useUser();

  const features = [
    {
      icon: <MessageCircle className="w-8 h-8 text-blue-600" />,
      title: "AI Chat Assistant",
      description:
        "Get instant, veterinary-approved answers to pet health and behavior questions 24/7",
    },
    {
      icon: <Calendar className="w-8 h-8 text-purple-600" />,
      title: "Smart Scheduling",
      description:
        "Automated care routines with intelligent reminders for feeding, walks, medications, and vet visits",
    },
    {
      icon: <Heart className="w-8 h-8 text-pink-600" />,
      title: "Health Journal",
      description:
        "Track symptoms, medications, and vet visits with photo documentation and timestamps",
    },
    {
      icon: <Users className="w-8 h-8 text-green-600" />,
      title: "Multi-Pet Support",
      description:
        "Manage multiple pets with individual profiles, schedules, and health records in one dashboard",
    },
  ];

  const testimonials = [
    {
      name: "Sarah M.",
      text: "The AI assistant helped me identify my dog's allergies. My vet was impressed with the detailed health logs!",
      rating: 5,
    },
    {
      name: "Mike R.",
      text: "Never missed a medication dose since using PetAssistent. The reminders are perfect and my cat is healthier than ever.",
      rating: 5,
    },
    {
      name: "Emma L.",
      text: "Managing three pets was chaos until I found PetAssistent. Everything is organized and automated now!",
      rating: 5,
    },
  ];

  const howItWorks = [
    {
      step: "1",
      title: "Add Your Pet",
      description:
        "Create detailed profiles with breed, age, weight, and medical history for personalized care",
    },
    {
      step: "2",
      title: "Set Up Care Routines",
      description:
        "Configure automated schedules for feeding, walks, medications, and vet appointments",
    },
    {
      step: "3",
      title: "Get AI Guidance",
      description:
        "Ask questions anytime and receive instant, accurate advice based on veterinary expertise",
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-green-500 border-t-transparent mx-auto mb-4"></div>
          <p className="text-green-700 font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  if (user) {
    // Redirect authenticated users to dashboard
    if (typeof window !== "undefined") {
      window.location.href = "/dashboard";
    }
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm border-b border-green-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <div className="bg-green-100 p-3 rounded-xl">
                <PawPrint className="w-8 h-8 text-green-600" />
              </div>
              <span className="text-2xl font-bold text-gray-800">
                PetAssistent
              </span>
            </div>
            <div className="flex items-center gap-4">
              <a
                href="/account/signin"
                className="text-gray-600 hover:text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-100 transition-colors font-medium"
              >
                Sign In
              </a>
              <a
                href="/account/signup"
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
              >
                Get Started
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="bg-green-100 p-4 rounded-full w-fit mx-auto mb-8">
            <PawPrint className="w-16 h-16 text-green-600" />
          </div>

          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Your AI-Powered
            <span className="text-green-600 block"> Pet Care Assistant</span>
          </h1>

          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Simplify pet care through automation, intelligent tracking, and
            instant AI-powered advice. Keep your furry friends healthy and happy
            with PetAssistent.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <a
              href="/account/signup"
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-colors inline-flex items-center justify-center gap-2"
            >
              Start Free Today
              <ArrowRight className="w-5 h-5" />
            </a>
            <a
              href="#features"
              className="border border-green-600 text-green-600 hover:bg-green-50 px-8 py-4 rounded-lg font-semibold text-lg transition-colors"
            >
              Learn More
            </a>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span>10,000+ Happy Pet Owners</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <span>4.9/5 Average Rating</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-green-600" />
              <span>Veterinary-Approved AI</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-white/60">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Everything You Need for Pet Care
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive tools to keep track of your pet's health, schedule
              care routines, and get expert advice whenever you need it.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-8 shadow-lg border border-green-100 hover:shadow-xl transition-all group text-center"
              >
                <div className="bg-gray-50 p-4 rounded-full w-fit mx-auto mb-6 group-hover:bg-gray-100 transition-colors">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              How PetAssistent Works
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our AI uses veterinary-approved knowledge to provide safe,
              thoughtful advice tailored to your pet's needs.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {howItWorks.map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-green-100 p-6 rounded-full w-fit mx-auto mb-6">
                  <span className="text-3xl font-bold text-green-600">
                    {step.step}
                  </span>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">
                  {step.title}
                </h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/60">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Designed for Every Pet Owner
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Whether you're a first-time pet owner or an experienced
                caregiver, PetAssistent provides the tools and knowledge you
                need to keep your pets healthy and happy.
              </p>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-1 rounded-full mt-1">
                    <Check className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">
                      Easy for Everyone
                    </h4>
                    <p className="text-gray-600">
                      Clean, intuitive interface that works great for tech-savvy
                      users and seniors alike.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-1 rounded-full mt-1">
                    <Check className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">
                      Veterinary-Approved
                    </h4>
                    <p className="text-gray-600">
                      All AI recommendations are based on veterinary expertise
                      and best practices.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-1 rounded-full mt-1">
                    <Check className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">
                      Secure & Private
                    </h4>
                    <p className="text-gray-600">
                      Your pet's data is encrypted and protected with
                      enterprise-grade security.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-1 rounded-full mt-1">
                    <Check className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">
                      Mobile Responsive
                    </h4>
                    <p className="text-gray-600">
                      Works perfectly on desktop, tablet, and mobile devices.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-100 to-blue-100 rounded-2xl p-8">
              <div className="bg-white rounded-xl p-6 shadow-lg mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <MessageCircle className="w-6 h-6 text-blue-600" />
                  </div>
                  <span className="font-semibold text-gray-800">
                    AI Assistant
                  </span>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg mb-3">
                  <p className="text-sm text-gray-700">
                    "Is chocolate toxic to dogs?"
                  </p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-700">
                    Yes, chocolate is toxic to dogs. Even small amounts can
                    cause vomiting, diarrhea, and in severe cases, seizures. If
                    your dog ate chocolate, contact your vet immediately...
                  </p>
                </div>
              </div>

              <div className="text-center">
                <p className="text-gray-600 font-medium">
                  Get instant, expert advice 24/7
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Loved by Pet Parents Everywhere
            </h2>
            <p className="text-xl text-gray-600">
              See what our community has to say about PetAssistent
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-8 shadow-lg border border-green-100 hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-5 h-5 text-yellow-500 fill-current"
                    />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 italic text-lg">
                  "{testimonial.text}"
                </p>
                <p className="font-semibold text-gray-800 text-lg">
                  {testimonial.name}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-green-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Give Your Pet the Best Care?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Join thousands of pet owners who trust PetAssistent to keep their
            furry friends healthy and happy.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-6">
            <a
              href="/account/signup"
              className="bg-white hover:bg-green-50 text-green-600 px-8 py-4 rounded-lg font-semibold text-lg transition-colors inline-flex items-center justify-center gap-2"
            >
              Start Your Free Account
              <ArrowRight className="w-5 h-5" />
            </a>
            <a
              href="/chat"
              className="border border-white text-white hover:bg-green-700 px-8 py-4 rounded-lg font-semibold text-lg transition-colors"
            >
              Try AI Assistant
            </a>
          </div>
          <p className="text-green-100 text-sm">
            No credit card required • Free forever • Secure & private
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="bg-green-100 p-2 rounded-lg">
                <PawPrint className="w-6 h-6 text-green-600" />
              </div>
              <span className="text-xl font-bold">PetAssistent</span>
            </div>
            <p className="text-gray-400 mb-6">
              Your AI-powered companion for better pet care
            </p>
            <div className="flex justify-center gap-8 text-sm text-gray-400">
              <a href="/privacy" className="hover:text-white transition-colors">
                Privacy Policy
              </a>
              <a href="/terms" className="hover:text-white transition-colors">
                Terms of Service
              </a>
              <a href="/contact" className="hover:text-white transition-colors">
                Contact
              </a>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-8 text-center text-gray-400">
            <p>
              &copy; 2024 PetAssistent. All rights reserved. Made with ❤️ for pet
              owners everywhere.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;
