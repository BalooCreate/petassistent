"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  PawPrint,
  Plus,
  Calendar,
  MessageCircle,
  Heart,
  Camera,
  Clock,
  Bell,
  Settings,
  LogOut,
  Activity,
  ArrowRight,
  CheckCircle,
  AlertCircle,
} from "lucide-react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [pets, setPets] = useState([]);
  const [upcomingSchedules, setUpcomingSchedules] = useState([]);
  const [recentHealthLogs, setRecentHealthLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalPets: 0,
    upcomingCare: 0,
    completedToday: 0,
    healthLogs: 0,
  });

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);

      // Fetch pets
      const petsResponse = await fetch("/api/pets");
      if (petsResponse.ok) {
        const petsData = await petsResponse.json();
        setPets(petsData.pets || []);
        setStats((prev) => ({
          ...prev,
          totalPets: petsData.pets?.length || 0,
        }));
      }

      // Fetch upcoming schedules
      const schedulesResponse = await fetch("/api/care-schedules");
      if (schedulesResponse.ok) {
        const schedulesData = await schedulesResponse.json();
        const upcoming =
          schedulesData.schedules?.filter(
            (schedule) =>
              schedule.next_due &&
              new Date(schedule.next_due) <=
                new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          ) || [];
        setUpcomingSchedules(upcoming.slice(0, 5));
        setStats((prev) => ({ ...prev, upcomingCare: upcoming.length }));
      }

      // Fetch recent health logs
      const logsResponse = await fetch("/api/health-logs");
      if (logsResponse.ok) {
        const logsData = await logsResponse.json();
        setRecentHealthLogs(logsData.logs?.slice(0, 5) || []);
        setStats((prev) => ({
          ...prev,
          healthLogs: logsData.logs?.length || 0,
        }));
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-green-500 border-t-transparent mx-auto mb-4"></div>
          <p className="text-green-700 font-medium">
            Loading your dashboard...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    if (typeof window !== "undefined") {
      window.location.href = "/account/signin";
    }
    return null;
  }

  const formatDate = (dateString) => {
    if (!dateString) return "Not scheduled";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getScheduleTypeIcon = (type) => {
    switch (type) {
      case "feeding":
        return "🍽️";
      case "walk":
        return "🚶";
      case "medication":
        return "💊";
      case "vet_appointment":
        return "🏥";
      default:
        return "📅";
    }
  };

  const getLogTypeIcon = (type) => {
    switch (type) {
      case "symptom":
        return "🩺";
      case "medication":
        return "💊";
      case "vet_visit":
        return "🏥";
      default:
        return "📝";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm border-b border-green-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <div className="bg-green-100 p-3 rounded-xl">
                <PawPrint className="w-8 h-8 text-green-600" />
              </div>
              <div>
                <span className="text-2xl font-bold text-gray-800">
                  PetAssistent
                </span>
                <p className="text-sm text-green-600">
                  Welcome back, {user.name || user.email}!
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors">
                <Bell className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors">
                <Settings className="w-5 h-5" />
              </button>
              <button
                onClick={() => (window.location.href = "/chat")}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                AI Chat
              </button>
              <a
                href="/account/logout"
                className="text-gray-600 hover:text-gray-800 p-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <LogOut className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Dashboard</h1>
          <p className="text-gray-600">
            Keep track of your pets' health, schedules, and get AI-powered
            advice
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 border border-green-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <PawPrint className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">
                  {stats.totalPets}
                </p>
                <p className="text-sm text-gray-600">Your Pets</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-green-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4">
              <div className="bg-orange-100 p-3 rounded-lg">
                <Clock className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">
                  {stats.upcomingCare}
                </p>
                <p className="text-sm text-gray-600">Upcoming Care</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-green-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">3</p>
                <p className="text-sm text-gray-600">Completed Today</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-green-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <Heart className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">
                  {stats.healthLogs}
                </p>
                <p className="text-sm text-gray-600">Health Records</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <button
            onClick={() => (window.location.href = "/pets/add")}
            className="bg-white rounded-xl p-6 shadow-sm border border-green-100 hover:shadow-md hover:border-green-200 transition-all text-center group"
          >
            <div className="bg-green-100 p-3 rounded-full w-fit mx-auto mb-3 group-hover:bg-green-200 transition-colors">
              <Plus className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-800">Add Pet</h3>
            <p className="text-sm text-gray-600">Register a new pet</p>
          </button>

          <button
            onClick={() => (window.location.href = "/care-schedule")}
            className="bg-white rounded-xl p-6 shadow-sm border border-green-100 hover:shadow-md hover:border-purple-200 transition-all text-center group"
          >
            <div className="bg-purple-100 p-3 rounded-full w-fit mx-auto mb-3 group-hover:bg-purple-200 transition-colors">
              <Calendar className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="font-semibold text-gray-800">Care Schedule</h3>
            <p className="text-sm text-gray-600">Manage routines</p>
          </button>

          <button
            onClick={() => (window.location.href = "/health-journal")}
            className="bg-white rounded-xl p-6 shadow-sm border border-green-100 hover:shadow-md hover:border-pink-200 transition-all text-center group"
          >
            <div className="bg-pink-100 p-3 rounded-full w-fit mx-auto mb-3 group-hover:bg-pink-200 transition-colors">
              <Heart className="w-6 h-6 text-pink-600" />
            </div>
            <h3 className="font-semibold text-gray-800">Health Journal</h3>
            <p className="text-sm text-gray-600">Track health records</p>
          </button>

          <button
            onClick={() => (window.location.href = "/chat")}
            className="bg-white rounded-xl p-6 shadow-sm border border-green-100 hover:shadow-md hover:border-blue-200 transition-all text-center group"
          >
            <div className="bg-blue-100 p-3 rounded-full w-fit mx-auto mb-3 group-hover:bg-blue-200 transition-colors">
              <MessageCircle className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-800">AI Assistant</h3>
            <p className="text-sm text-gray-600">Get pet care advice</p>
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* My Pets */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-green-100 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                  <Heart className="w-5 h-5 text-pink-500" />
                  My Pets
                </h2>
                <button
                  onClick={() => (window.location.href = "/pets/add")}
                  className="text-green-600 hover:text-green-700 p-2 hover:bg-green-50 rounded-lg transition-colors"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>

              {pets.length === 0 ? (
                <div className="text-center py-8">
                  <div className="bg-green-100 p-4 rounded-full w-fit mx-auto mb-4">
                    <PawPrint className="w-8 h-8 text-green-600" />
                  </div>
                  <p className="text-gray-600 mb-4">No pets added yet</p>
                  <button
                    onClick={() => (window.location.href = "/pets/add")}
                    className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
                  >
                    Add Your First Pet
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {pets.map((pet) => (
                    <div
                      key={pet.id}
                      className="group flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-green-50 hover:border-green-200 border border-transparent transition-all cursor-pointer"
                      onClick={() => (window.location.href = `/pets/${pet.id}`)}
                    >
                      <div className="w-16 h-16 bg-gradient-to-br from-green-100 to-blue-100 rounded-full flex items-center justify-center">
                        {pet.photo_url ? (
                          <img
                            src={pet.photo_url}
                            alt={pet.name}
                            className="w-16 h-16 rounded-full object-cover"
                          />
                        ) : (
                          <PawPrint className="w-8 h-8 text-green-600" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800 group-hover:text-green-700 transition-colors">
                          {pet.name}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {pet.breed && `${pet.breed}`}
                          {pet.age && ` • ${pet.age} years old`}
                        </p>
                        {pet.weight && (
                          <p className="text-xs text-gray-500">
                            {pet.weight} lbs
                          </p>
                        )}
                      </div>
                      <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-green-500 transition-colors" />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Upcoming Schedules & Recent Health Logs */}
          <div className="lg:col-span-2 space-y-8">
            {/* Upcoming Schedules */}
            <div className="bg-white rounded-xl shadow-sm border border-green-100 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-blue-500" />
                  Upcoming Care
                </h2>
                <button
                  onClick={() => (window.location.href = "/care-schedule")}
                  className="text-blue-600 hover:text-blue-700 text-sm font-medium hover:bg-blue-50 px-3 py-1 rounded-lg transition-colors"
                >
                  View All
                </button>
              </div>

              {upcomingSchedules.length === 0 ? (
                <div className="text-center py-8">
                  <div className="bg-green-100 p-4 rounded-full w-fit mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <p className="text-gray-600">
                    All caught up! No upcoming schedules.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {upcomingSchedules.map((schedule) => (
                    <div
                      key={schedule.id}
                      className="flex items-center gap-4 p-4 bg-orange-50 rounded-lg border border-orange-100"
                    >
                      <div className="bg-orange-100 p-2 rounded-lg">
                        <AlertCircle className="w-5 h-5 text-orange-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800">
                          {schedule.title}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {schedule.pet_name && `${schedule.pet_name} • `}
                          {formatDate(schedule.next_due)}
                        </p>
                      </div>
                      <Bell className="w-5 h-5 text-orange-500" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Recent Health Logs */}
            <div className="bg-white rounded-xl shadow-sm border border-green-100 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-purple-500" />
                  Recent Activity
                </h2>
                <button
                  onClick={() => (window.location.href = "/health-journal")}
                  className="text-purple-600 hover:text-purple-700 text-sm font-medium hover:bg-purple-50 px-3 py-1 rounded-lg transition-colors"
                >
                  View All
                </button>
              </div>

              {recentHealthLogs.length === 0 ? (
                <div className="text-center py-8">
                  <div className="bg-gray-100 p-4 rounded-full w-fit mx-auto mb-4">
                    <Activity className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-600 mb-4">No health logs yet</p>
                  <button
                    onClick={() => (window.location.href = "/health-journal")}
                    className="text-purple-600 hover:text-purple-700 font-medium"
                  >
                    Start logging health records →
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentHealthLogs.map((log) => (
                    <div
                      key={log.id}
                      className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-purple-50 transition-colors"
                    >
                      <div className="bg-purple-100 p-2 rounded-lg">
                        <Heart className="w-5 h-5 text-purple-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800">
                          {log.title}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {log.pet_name && `${log.pet_name} • `}
                          {formatDate(log.date_logged)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;
